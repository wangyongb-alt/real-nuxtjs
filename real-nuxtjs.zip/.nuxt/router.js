import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _24c77d92 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _44aa1d72 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _5028fffe = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _64325441 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _994f76ea = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _18f8a3d5 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _4afc978e = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _24c77d92,
    children: [{
      path: "",
      component: _44aa1d72,
      name: "home"
    }, {
      path: "/login",
      component: _5028fffe,
      name: "login"
    }, {
      path: "/register",
      component: _5028fffe,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _64325441,
      name: "profile"
    }, {
      path: "/settings",
      component: _994f76ea,
      name: "settings"
    }, {
      path: "/editor",
      component: _18f8a3d5,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _4afc978e,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
